# LAN ANH CLIENT PVP BETA (Fabric 1.21.4)

Mod client-side: Elytra Mace, Auto Crystal/Pearl, Safe Anchor, ESP + dây, ESP Block, Radar, Printer schematic.

## Build bằng GitHub (không cần cài gì)
1. Tạo repo GitHub, upload toàn bộ thư mục này.
2. Tab **Actions** -> workflow **Build** chạy tự động -> tải artifact `LanAnhClient-jar`.
3. Bỏ file `.jar` vào `.minecraft/mods` cùng **Fabric Loader 0.16+** và **Fabric API 0.119.2+1.21.4**.

## Phím mặc định (đổi trong Controls)
RShift = menu • R = Elytra Mace • G = Safe Anchor • P = Printer

## Schematic
Đặt file `.litematic` vào `.minecraft/schematics/`, vào menu -> *Xây theo Schematic* -> chọn file -> đứng vào gốc muốn xây -> bật Printer.

## Hình nền (Hello Kitty hoặc ảnh bất kỳ của bạn)
Đặt ảnh PNG 512x512 tại `src/main/resources/assets/safeanchor/textures/gui/bg.png`. Không có ảnh thì dùng nền hồng.


## v2.3 (mới)
- Block ESP: chỉnh độ đậm màu; quét nhẹ hơn (giảm lag), khung schematic cache
- Mace liên tục (Menu > Elytra Mace), Auto PvP (V), Tự đào kiểu Baritone (N)
- Printer: xây theo hàng (tự chuyển hàng), chỉ đặt theo hướng nhìn, tự đi tới chỗ xây
- Auto /ah mua, Sus chunk (đỏ), Dịch chat Anh <-> Việt

## v2.4
- Menu: animation chữ CLIENTS BY LAN ANH, chia hàng module (ESP / PvP / Xây / Hiển thị / Khác), vuốt ngang để đổi hàng
- Shockwave, Trail, Chroma, đổi giờ bầu trời, Velocity, Combo Anchor 1 phím (J), HUD FPS/Ping/RAM/Keystrokes

## v2.5 (học từ PURXIY)
Jump Circle, Ripple, Block Outline trượt, Place Animation, Triggerbot, Hit Select, Silent Aura, Configs, HUD CPS/thuốc/giáp/combo/module list

## v2.6
Hit Splash, Target ESP, Radiance, Afterglow, lưới Cyberspace, Shockwave ô sáng, Bridge, Name Tags, vòng tâm ngắm, đếm Totem

## v2.7
- Bảng màu mới (mọi chỗ chọn màu): chuột phải kéo / click vào lưới màu hoặc hàng màu nhạt
- Ô nhập item/block có hình 2D: gõ "log" -> hiện toàn bộ, vuốt lên/xuống, chạm để thêm (ESP Block, Tự đào, Auto /ah)
- Chặn mở rương / hopper / shulker / thùng... (ngồi shift để mở) • Macro Crystal • Tâm tự vẽ • Bầu trời ảo (màu tùy chỉnh)
- Trail: dưới chân / giữa người / trên đầu • Shockwave khối nhô lên rồi rớt xuống từ từ
- Safe Anchor: 1 click, đúng 1 obsidian chắn rồi nổ • Elytra Mace: chuỗi đập (bị hất lên nhẹ -> dùng cánh lao xuống đập tiếp) • bỏ Mace liên tục
- Workflow build: repo có thể để source ở thư mục gốc hoặc bằng file lananh-client-source.zip

## v2.8
- Spin Bot: nhân vật xoay (người khác thấy), camera đứng yên, chỉnh tốc độ/hướng

## v2.9
- Bỏ Spin Bot
- Radar: tự quét xuyên tường (không cần nhìn thấy), block hiện icon 2D, ▲ trên / ▼ dưới kèm chênh cao
- Mace: thả rơi thẳng theo đà (không lao chéo nên hết bị bật qua đầu), đập ngay khi rơi (smash không cần cooldown đầy)
- "Chân ngang đầu": cầm mace, đang rơi, chân hạ tới ngang đầu đối thủ là đánh luôn
- Macro tự thiết kế (phím K): xếp bước anchor / glowstone / obsidian / crystal / totem / chờ... theo ý muốn
- Trượt mượt khi tp (pearl, chorus...): camera lướt từ chỗ cũ tới chỗ mới
- Âm bàn phím kiểu Creamy Keys

## v2.10
- Anchor Shield: tự đặt anchor, tự nạp 1-4 glowstone, bấm nổ -> client đặt NGAY 1 obsidian (hết thì glowstone) phía mình trước khi gói tin nổ gửi đi. Ô chắn chỉ che tia nổ tới bạn; nếu ô đó cũng che đối thủ hoặc đè lên đối thủ thì không đặt.
- Macro Crystal: đập tối đa 30 crystal / tick (menu chỉnh), tự đặt lại crystal ngay trong tick, không bị Hit Select chặn

## v2.10.1
- Fix Safe Anchor / Combo Anchor / Macro: không còn đặt obsidian ngay khi vừa đặt anchor. Thứ tự mới: đặt anchor -> nạp glowstone -> (sắp nổ) đặt 1 block chắn phía mình -> nổ. Block chắn dùng cùng logic Anchor Shield (không che đối thủ, không bấm vào mặt anchor)

## v2.11
- Dò căn cứ (menu ESP -> "Dò căn cứ"): Sus ESP (block người đặt dưới lòng đất), Spawner ESP, Storage ESP, Hole ESP (hố obsidian/bedrock), Lightfinder (nguồn sáng lạ), Chunk Finder v2 (hiện tọa độ chunk đáng nghi ở HUD)
- Cài đặt module (chuột phải vào module, hoặc nút ⚙): phím tắt riêng, Alpha, Min/Max Y, tầm quét, màu, bộ lọc loại block
- Chế độ Safe / Risk / Unsafe: Safe chậm + ngẫu nhiên như người, Unsafe tối đa (áp dụng cho Macro Crystal, Combo Anchor, Macro K)

## v9 — Module Menu 7 tab
- Mở bằng **Insert** (hoặc nút 🧩 đầu menu RShift). 7 tab: Combat / Movement / Player / Render / World / Misc / HUD.
- Chuột trái vào module = bật/tắt • **chuột phải = mở/đóng bảng cài đặt**: Mode, Slider, Checkbox, Keybind, Color Picker (Alpha + Rainbow).
- Cài đặt lưu ở `config/lananh-modules.json`. Module ghi "(chưa có logic)" mới có giao diện, chưa có chức năng.

## v2.12
- Menu chính (Right Shift / Insert) mở thẳng Module Menu kiểu Meteor: chạm trái = bật/tắt, chạm phải = cài đặt (ngắn gọn). Chọn hàng bằng thanh tab, không còn mũi tên trái/phải. "Menu cũ" ở góc trên phải.
- Module mới trong menu: ElytraMace, WindMace, MacroCrystal, AnchorShield, Aimbot, Surround, SusESP, SpawnerESP, HoleESP, Lightfinder, ChunkFinder, Radar, Trail, TpGlide, KeySound, Chế độ (Safe/Risk/Unsafe), Giao diện
- Giao diện: nền menu Tối / Màu / Gradient / Ảnh (PNG tại .minecraft/config/lananh-bg.png), độ tối, độ đậm khung giữa
- Fix Elytra Mace: không bắn pháo khi đang rơi hoặc chúi mũi xuống

## v2.13
- ElytraMace: kiểu "Lao pháo" (elytra + pháo lao xuống đập rồi bay lên lại) bên cạnh kiểu "Thả rơi"
- ElytraMace: "Đuổi" - đối thủ chạy / pearl xa thì bay elytra đón đầu rồi đánh
- Cài đặt ElytraMace có hình 2D xem trước đường bay, đổi theo từng thông số (Cao, Lệch, Đổi áo, Đánh)

## v2.14
- Bỏ dây tracer "trên màn hình" (dây ở trên cùng giữa màn hình)
- ElytraMace: tầm tìm đối thủ tới 300, "Bay tìm": không thấy đối thủ thì bay elytra tới chỗ thấy lần cuối rồi vòng xoắn rộng dần để tìm (tối đa "Tìm (giây)")
- ElytraMace "Lao pháo": đổi áo muộn theo tốc độ, để pháo kịp đẩy lao xuống (trước đây đổi áo ngay nên gần như không bắn pháo)

## v2.15
- ElytraMace: "Khóa 1 mục tiêu" - chọn đúng 1 người (gần nhất lúc bắt đầu) và đánh tới khi họ chết / thoát / ra khỏi tầm, không còn nhảy qua lại giữa nhiều người

## v2.16
- Module menu: icon item 2D cho từng module (ElytraMace = cục mace, ESP = mắt ender, ...), chữ mô tả rút gọn
- ElytraMace: đủ toàn bộ cấu hình mace (góc nhìn, đổi áo, tự đánh, chuỗi đập, thả thẳng, đạp đầu...) với tên ngắn
- Cài đặt ElytraMace / WindMace có màn hình nhỏ: "Mình" (có cánh) và "BOT" bay đánh theo đúng thông số đang chỉnh

## v2.17
- Translate (module MISC): gõ gì cũng tự dịch sang ngôn ngữ "Gửi sang" (mặc định English) rồi mới gửi; tin của người khác được ĐỔI THẲNG sang "Nhận sang" (mặc định Việt), dòng gốc bị ẩn
- Mod Menu: ở màn hình chính -> Mods -> "lan anh client" -> nút cài đặt mở thẳng Module Menu, không cần vào game (cần cài Mod Menu)
- Có icon mod (không còn dấu "?")

## v2.18
- Fix Elytra Mace bay vòng vòng: chốt "đã tới phía trên" có độ trễ, không đòi cao quá giới hạn thế giới, bay lên quá lâu thì tự nới điều kiện để lao xuống
- BaseFinder (WORLD): nhập X Z, Y xây, kích thước (hoặc theo schematic), xa hang N chunk -> tìm khu không hang, hiện 4 trụ sáng ở 4 góc, chunk có hang đỏ
- FreeDig (WORLD): bật module = freecam; bay tới góc trên bấm phím (mặc định G), bay xuống góc dưới bấm lần nữa -> bot tự đào cả vùng từ trên xuống, khung neon vàng + tầng đang đào
- Tự cầm đúng dụng cụ khi đào, đập hết block/cây trong tầm trước khi đi chỗ khác
- Âm phím: file âm thanh riêng kiểu Creamy Keys (Creamy / Thock / Clicky), có tiếng nhả, Space/Enter trầm hơn, chỉnh âm lượng
- Menu: slider "Trong suốt %" (module Giao diện), menu cũ không còn bị module ghi đè khi bật tắt

## v2.19
- KeySound dùng 7 bộ Cherry MX của bạn (mỗi phím một mẫu); "Toàn game": thay tiếng menu / cài đặt / chuột / mọi thứ trong Minecraft bằng tiếng phím
- TunnelDig: đào hầm thẳng Bắc / Nam / Đông / Tây / theo nhìn / xuống bậc thang; kiểu Cúp thường (1x2) và Amethyst 3x3; vá sàn bằng block thường
- BaseFinder chỉ tính hang từ deepslate (Y <= "Hang từ Y") trở xuống
- SusESP bỏ block của Trail Ruins; SpawnerESP ẩn lồng quái tự nhiên (dungeon / mineshaft / trial)
- Hướng dẫn: nút "Hướng dẫn" trong menu + file HUONG_DAN.md
