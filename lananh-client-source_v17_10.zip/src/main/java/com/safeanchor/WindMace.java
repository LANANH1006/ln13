package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Mace liên tục kiểu "mace combo": chạy tới đối thủ -> nhìn xuống ném WIND CHARGE dưới chân (bị hất lên cao)
 * -> cầm mace, canh đầu đối thủ và rơi xuống smash -> đáp xuống rồi lặp lại.
 * Cần: mace + wind charge trong túi. Không cần elytra / pháo.
 */
public class WindMace {
    static int cd, throwCd;
    static boolean keys;

    static void release(MinecraftClient mc) {
        if (keys) { mc.options.forwardKey.setPressed(false); keys = false; }
    }

    public static void toggle(MinecraftClient mc) {
        Config.I.windMace = !Config.I.windMace;
        if (mc.player == null) { Config.save(); return; }   // đang ở menu chính (Mod Menu), chưa vào game
        if (!Config.I.windMace) release(mc);
        Util.msg("Mace liên tục (wind charge): " + (Config.I.windMace ? "§aBẬT" : "§cTẮT"));
        Config.save();
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (!c.windMace || !c.enabled || p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) { release(mc); return; }
        if (c.autoMace || AnchorCombo.stage != 0 || p.isGliding() || p.isSpectator() || p.isDead()) { release(mc); return; }
        if (cd > 0) cd--;
        if (throwCd > 0) throwCd--;

        PlayerEntity t = Util.nearestEnemy(c.windRange);
        if (t == null) { release(mc); return; }
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());

        if (p.isOnGround()) {
            if (cd > 0 || throwCd > 0) return;
            if (horiz > c.windStartDist) {                       // chạy tới gần đối thủ
                Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
                mc.options.forwardKey.setPressed(true); keys = true;
                return;
            }
            release(mc);
            if (!Util.has(s -> s.isOf(Items.WIND_CHARGE))) { Util.warn("Không có wind charge!"); return; }
            if (!Util.selectItem(s -> s.isOf(Items.WIND_CHARGE))) return;
            float op = p.getPitch();
            p.setPitch(90f);                                       // nhìn thẳng xuống: nổ ngay dưới chân -> bay lên
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            p.setPitch(op);
            throwCd = 15;
            return;
        }

        // ===== đang trên không: cầm mace, canh đối thủ, rơi xuống smash =====
        if (!Util.selectItem(s -> s.isOf(Items.MACE))) { Util.warn("Không có mace!"); release(mc); return; }
        Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
        if (horiz > 1.2) { mc.options.forwardKey.setPressed(true); keys = true; } else release(mc);
        if (dist <= c.maceHitDist && p.getVelocity().y < 0 && p.getAttackCooldownProgress(0.5f) >= c.windMinCd / 100f) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            cd = 8;
        }
    }
}
