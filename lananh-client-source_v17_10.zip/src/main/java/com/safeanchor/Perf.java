package com.safeanchor;

/** Cài đặt hiệu năng cho phần quét / vẽ của mod. */
public class Perf {
    public static boolean lite() { return Config.I.perfLite; }
    /** Số tick giữa 2 lần quét chunk. */
    public static int gap() { return lite() ? 4 : 2; }
    /** Số tick giữa 2 lần dựng lại danh sách block để vẽ. */
    public static int outGap() { return lite() ? 6 : 3; }
}
