package com.safeanchor;

import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.VaultBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

/**
 * Canh Vault (Trial Vault, kể cả Ominous xanh): đứng gần, thấy món hiện trong lồng đúng món mình chọn
 * (Heavy Core / Táo vàng phù phép / Sách phù phép) thì tự chọn key và chuột phải quay NGAY lập tức.
 */
public class VaultWatch {
    static int cd;
    static boolean warnedKey;

    static boolean wanted(ItemStack s) {
        Config c = Config.I;
        return (c.vaultHeavy && s.isOf(Items.HEAVY_CORE))
                || (c.vaultApple && s.isOf(Items.ENCHANTED_GOLDEN_APPLE))
                || (c.vaultBook && s.isOf(Items.ENCHANTED_BOOK));
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.vaultOn || !c.enabled || p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0) { cd--; return; }
        double range = Math.min(c.vaultRange, c.reach);
        int pcx = p.getBlockX() >> 4, pcz = p.getBlockZ() >> 4;
        for (int cx = pcx - 1; cx <= pcx + 1; cx++) for (int cz = pcz - 1; cz <= pcz + 1; cz++) {
            WorldChunk ch = w.getChunkManager().getWorldChunk(cx, cz);
            if (ch == null) continue;
            for (BlockEntity be : ch.getBlockEntities().values()) {
                if (!(be instanceof VaultBlockEntity vbe)) continue;
                BlockPos pos = be.getPos();
                Vec3d ctr = Vec3d.ofCenter(pos);
                if (p.getEyePos().distanceTo(ctr) > range) continue;
                String st = w.getBlockState(pos).toString();
                boolean ominous = st.contains("ominous=true");
                if (c.vaultOminousOnly && !ominous) continue;                 // chỉ vault xanh (cần Ominous Trial Key)
                if (!st.contains("vault_state=active")) continue;             // đang mở/đang nhả đồ thì bỏ qua
                ItemStack disp = vbe.getSharedData().getDisplayItem();
                if (disp == null || disp.isEmpty() || !wanted(disp)) continue;

                Item key = ominous ? Items.OMINOUS_TRIAL_KEY : Items.TRIAL_KEY;
                if (!Util.selectItem(s -> s.isOf(key))) {
                    if (!warnedKey) { warnedKey = true; Util.warn("Có " + disp.getName().getString() + " trong lồng nhưng thiếu " + (ominous ? "Ominous Trial Key" : "Trial Key")); }
                    continue;
                }
                warnedKey = false;
                Direction face = Direction.getFacing(p.getEyePos().x - ctr.x, p.getEyePos().y - ctr.y, p.getEyePos().z - ctr.z);
                Util.aim(p, ctr);
                if (Util.useOnBlock(pos, face)) {                              // chuột phải quay ngay
                    Util.msg("Quay vault: " + disp.getName().getString());
                    cd = 40;
                    return;
                }
            }
        }
    }
}
