package com.safeanchor;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.ShaderProgramKeys;
import net.minecraft.client.render.*;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.world.World;
import org.joml.Matrix4f;

/**
 * Bầu trời ảo: vẽ mặt cầu màu (chân trời -> trên cao) ở rất xa, chỉ hiện ở chỗ trời trống (depth test),
 * nên không đè lên địa hình/vật thể. Chọn màu bằng bảng màu (có hàng màu nhạt).
 */
public class SkyBox {
    public static void render(WorldRenderContext ctx) {
        MinecraftClient mc = MinecraftClient.getInstance(); Config c = Config.I;
        if (!c.skyColorOn || !c.enabled || mc.world == null || mc.player == null) return;
        if (mc.world.getRegistryKey() != World.OVERWORLD) return;
        MatrixStack ms = ctx.matrixStack();
        if (ms == null) return;
        Matrix4f m = ms.peek().getPositionMatrix();
        double R = Math.max(96, mc.options.getClampedViewDistance() * 16 * 1.5);
        int top = c.chroma ? Util.chroma(0) : c.skyTopColor, hor = c.chroma ? Util.chroma(0.12) : c.skyHorizonColor;
        int SEG = Perf.lite() ? 16 : 28, RINGS = Perf.lite() ? 8 : 14;
        double[] cb = new double[SEG + 1], sb = new double[SEG + 1], ca = new double[RINGS + 1], sa = new double[RINGS + 1];
        for (int j = 0; j <= SEG; j++) { double b = Math.PI * 2 * j / SEG; cb[j] = Math.cos(b); sb[j] = Math.sin(b); }
        for (int i = 0; i <= RINGS; i++) { double a = -Math.PI / 2 + Math.PI * i / RINGS; ca[i] = Math.cos(a); sa[i] = Math.sin(a); }

        RenderSystem.enableDepthTest();
        RenderSystem.depthMask(false);
        RenderSystem.disableBlend();
        RenderSystem.disableCull();
        RenderSystem.setShader(ShaderProgramKeys.POSITION_COLOR);
        BufferBuilder bb = Tessellator.getInstance().begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < RINGS; i++) {
            double a0 = -Math.PI / 2 + Math.PI * i / RINGS, a1 = -Math.PI / 2 + Math.PI * (i + 1) / RINGS;
            int c0 = shade(a0, top, hor), c1 = shade(a1, top, hor);
            for (int j = 0; j < SEG; j++) {
                Esp.v(bb, m, R * ca[i] * cb[j], R * sa[i], R * ca[i] * sb[j], c0, 255);
                Esp.v(bb, m, R * ca[i] * cb[j + 1], R * sa[i], R * ca[i] * sb[j + 1], c0, 255);
                Esp.v(bb, m, R * ca[i + 1] * cb[j + 1], R * sa[i + 1], R * ca[i + 1] * sb[j + 1], c1, 255);
                Esp.v(bb, m, R * ca[i + 1] * cb[j], R * sa[i + 1], R * ca[i + 1] * sb[j], c1, 255);
            }
        }
        BufferRenderer.drawWithGlobalProgram(bb.end());
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
    }

    static int shade(double ang, int top, int hor) {
        double t = ang <= 0 ? 0 : Math.pow(Math.sin(ang), 0.55);
        return Trail.lerp(hor, top, t);
    }
}
