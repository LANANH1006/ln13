package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;

/**
 * Chân ngang đầu: đang cầm mace và rơi xuống, hễ 2 chân hạ tới ngang đỉnh đầu đối thủ (đứng ngay bên dưới)
 * là đánh luôn, không chờ cooldown, không chờ lao thêm (mace smash không cần cooldown đầy).
 */
public class HeadHit {
    static int cd;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player;
        if (cd > 0) cd--;
        if (!c.headHit || !c.enabled || p == null || mc.world == null || mc.interactionManager == null || mc.currentScreen != null) return;
        if (cd > 0 || !p.getMainHandStack().isOf(Items.MACE)) return;
        if (p.isOnGround() || p.isGliding() || p.getVelocity().y >= -0.1 || p.fallDistance <= 1.5) return;

        double vy = Math.min(0.0, p.getVelocity().y);
        PlayerEntity best = null; double bd = 1e9;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == p || o.isSpectator() || !o.isAlive()) continue;
            double head = o.getY() + o.getHeight();
            double dy = p.getY() - head;                       // > 0: chân còn cao hơn đầu đối thủ
            double horiz = Math.hypot(p.getX() - o.getX(), p.getZ() - o.getZ());
            if (horiz > c.headHitHoriz) continue;
            if (dy > c.headHitTol || dy < -0.6 + vy) continue; // rơi nhanh thì mở rộng cửa sổ để khỏi lọt qua
            if (Util.distToBox(p.getEyePos(), o.getBoundingBox()) > 3.4) continue;
            if (horiz < bd) { bd = horiz; best = o; }
        }
        if (best == null) return;
        mc.interactionManager.attackEntity(p, best);
        p.swingHand(Hand.MAIN_HAND);
        ElytraMace.onHit();
        cd = 4;
    }
}
