package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/**
 * Đào hầm thẳng:
 *  - Kiểu 0: 2x1 (rộng 1, cao 2, cúp thường)  - Kiểu 1: 3x3 (cúp amethyst)  - Kiểu 2: 1x1 (hầm bò, cao 1)
 *  - Gặp lava phía trước: rẽ sang hướng khác đào tiếp, hết lava ở hướng cũ thì quay lại hướng cũ.
 *  - Đào xong (hoặc dừng): tự quay lại, cúi nhìn từng ô và đặt đúng loại block đã đào để lấp lại (giống block tự nhiên).
 *  - Tự tìm chỗ không hang: đào bậc thang xuống độ sâu mà cả đoạn hầm + trần phía trên đều là đá đặc (kể cả đoạn stone -> deepslate).
 *  - Tìm chỗ cho schematic: như trên nhưng theo kích thước schematic, tới nơi thì dừng (không lấp).
 */
public class TunnelDig {
    public static boolean on;
    static int phase;                 // 0 mới bật, 1 đào bậc thang xuống độ sâu đã chọn, 2 đào hầm, 3 lấp lại
    static Direction dir, origDir;
    static int dug, stuck, detour, targetY;
    static BlockPos lastPos;
    static boolean held;

    static final Direction[] HD = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    static final Set<Block> JUNK = Set.of(Blocks.COBBLESTONE, Blocks.DIRT, Blocks.NETHERRACK, Blocks.COBBLED_DEEPSLATE, Blocks.STONE, Blocks.ANDESITE,
            Blocks.DIORITE, Blocks.GRANITE, Blocks.TUFF, Blocks.DEEPSLATE);

    // ghi nhớ để lấp lại
    static final List<BlockPos> stands = new ArrayList<>();          // chỗ đứng ở mỗi bước
    static final List<List<BlockPos>> mined = new ArrayList<>();     // các ô đã đào khi đứng ở stands[i]
    static List<BlockPos> cur = new ArrayList<>();
    static final Map<Long, Block> was = new HashMap<>();             // block gốc của từng ô
    static int refillIdx, cellIdx, fails, missing;
    static final ArrayDeque<BlockPos> pending = new ArrayDeque<>();   // ô cần đặt lại ngay phía sau lưng (đào 1 đặt 1 / đào 2 đặt 2)
    static boolean warnedMissing;

    // chế độ "đoạn" do AreaSweep điều khiển (FreeDig + cúp amethyst): luôn 3x3, không rẽ lava, không lấp, không vá sàn
    public static boolean ext, extDone; static int extSteps, modeOverride = -1;
    static int mode() { return modeOverride >= 0 ? modeOverride : Config.I.tnMode; }
    static boolean rolling() { return Config.I.tnRefill && !ext && mode() != 1; }

    public static void beginSegment(MinecraftClient mc, Direction d, int steps) {
        ext = true; extDone = false; extSteps = steps; modeOverride = 1;
        on = true; phase = 2; dir = d; origDir = null; dug = 0; stuck = 0; pending.clear();
        if (stands.isEmpty()) stands.add(mc.player.getBlockPos());
    }
    public static void abort(MinecraftClient mc) { if (on || ext) reset(mc); }

    public static void setOn(boolean v) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (v == on) return;
        if (v) {
            if (mc.player == null) { Util.msg("Vào thế giới rồi mới bật"); return; }
            on = true; phase = 0; dir = null; origDir = null; dug = 0; stuck = 0; detour = 0;
            Util.msg("Đào hầm: " + modeName());
            return;
        }
        // tắt tay: nếu đang đào và bật "Lấp lại" thì quay lại lấp trước
        reset(mc);
    }

    static String modeName() { return switch (mode()) { case 1 -> "3x3 (amethyst)"; case 2 -> "1x1 (bò)"; default -> "2x1 (cúp thường)"; }; }

    static boolean hasRecords() { flush(); for (var l : mined) if (!l.isEmpty()) return true; return false; }

    static void flush() {
        if (!cur.isEmpty() || mined.size() < stands.size()) {
            while (mined.size() < stands.size()) { mined.add(cur); cur = new ArrayList<>(); }
        }
    }

    static void reset(MinecraftClient mc) {
        on = false; phase = 0; dir = null; origDir = null; ext = false; modeOverride = -1; pending.clear();
        release(mc);
        stands.clear(); mined.clear(); cur = new ArrayList<>(); was.clear();
        Config.save(); ModuleManager.save();
    }

    static void release(MinecraftClient mc) {
        if (held) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); held = false; }
    }

    static void stop(MinecraftClient mc, String why) {
        Util.msg("Đào hầm dừng: " + why);
        reset(mc);
    }

    static void startRefill(MinecraftClient mc) {
        flush(); release(mc);
        for (var l : mined) l.sort(Comparator.comparingInt(BlockPos::getY));      // lấp từ dưới lên
        phase = 3; refillIdx = mined.size() - 1; cellIdx = 0; fails = 0; missing = 0;
        Util.msg("Đào xong - quay lại lấp hầm...");
    }

    // ---------- hình dạng hầm ----------
    static int half() { return mode() == 1 ? 1 : 0; }
    static int up() { return switch (mode()) { case 1 -> 2; case 2 -> 0; default -> 1; }; }   // số ô phía trên chân

    static List<BlockPos> cellsFor(BlockPos feet, Direction d, boolean stair) {
        BlockPos ahead = feet.offset(d);
        Direction side = d.rotateYClockwise();
        int y0 = stair ? -1 : 0, y1 = up();
        List<BlockPos> cells = new ArrayList<>();
        for (int l = -half(); l <= half(); l++) for (int dy = y0; dy <= y1; dy++) cells.add(ahead.offset(side, l).up(dy));
        BlockPos mid = ahead.up();
        cells.sort(Comparator.comparingDouble(a -> Vec3d.ofCenter(a).squaredDistanceTo(Vec3d.ofCenter(mid))));   // block giữa trước
        return cells;
    }

    static boolean lavaIn(World w, List<BlockPos> cells) {
        for (BlockPos q : cells) if (AutoMine.lava(w, q) || AutoMine.nearLava(w, q)) return true;
        return false;
    }

    static Direction pickDir(net.minecraft.client.network.ClientPlayerEntity p) {
        return switch (Config.I.tnDir) {
            case 1 -> Direction.NORTH; case 2 -> Direction.SOUTH; case 3 -> Direction.EAST; case 4 -> Direction.WEST;
            default -> Direction.fromHorizontalDegrees(p.getYaw());
        };
    }

    static boolean solidFloor(World w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        return !s.getCollisionShape(w, p).isEmpty() && s.getFluidState().isEmpty();
    }

    static boolean junk(ItemStack s) { return s.getItem() instanceof BlockItem bi && JUNK.contains(bi.getBlock()); }

    // ---------- tìm chỗ không hang ----------
    static boolean rock(World w, BlockPos q) {
        if (!w.getChunkManager().isChunkLoaded(q.getX() >> 4, q.getZ() >> 4)) return false;
        BlockState s = w.getBlockState(q);
        return !s.isAir() && s.getFluidState().isEmpty() && !s.isReplaceable() && s.getHardness(w, q) >= 0;
    }

    /** Kích thước cần: {nửa rộng, số ô cao phía trên, chiều dài}. Có schematic + bật "tìm chỗ schematic" thì theo schematic. */
    static int[] need() {
        Config c = Config.I;
        if (c.tnSchem && !Printer.blocks.isEmpty()) {
            int ax = Integer.MAX_VALUE, bx = Integer.MIN_VALUE, ay = ax, by = bx, az = ax, bz = bx;
            for (long k : Printer.blocks.keySet()) {
                BlockPos q = BlockPos.fromLong(k);
                ax = Math.min(ax, q.getX()); bx = Math.max(bx, q.getX()); ay = Math.min(ay, q.getY()); by = Math.max(by, q.getY());
                az = Math.min(az, q.getZ()); bz = Math.max(bz, q.getZ());
            }
            int dx = bx - ax + 1, dy = by - ay + 1, dz = bz - az + 1;
            return new int[]{(Math.min(dx, dz) + 1) / 2, dy, Math.max(dx, dz)};
        }
        return new int[]{half(), up(), c.tnLen > 0 ? Math.min(c.tnLen, 64) : 32};
    }

    static boolean volumeSolid(World w, BlockPos f, Direction d, int y, int[] n) {
        int hw = n[0], hu = n[1], L = n[2];
        int drop = f.getY() - y;
        Direction side = d.rotateYClockwise();
        for (int k = 1; k <= drop; k++) {                                   // đoạn bậc thang đi xuống
            BlockPos s = f.offset(d, k).up(-k);
            for (int l = -hw - 1; l <= hw + 1; l++) for (int dy = -2; dy <= hu; dy++)
                if (!rock(w, s.offset(side, l).up(dy))) return false;
        }
        BlockPos b = f.offset(d, drop).withY(y);
        for (int k = 1; k <= L; k++) {                                      // đoạn hầm ngang + tường + sàn + trần (3 ô phía trên)
            BlockPos s = b.offset(d, k);
            for (int l = -hw - 1; l <= hw + 1; l++) for (int dy = -2; dy <= hu + 3; dy++)
                if (!rock(w, s.offset(side, l).up(dy))) return false;
        }
        return true;
    }

    /** Trả {chỉ số hướng, Y} gần nhất tìm được, hoặc null. */
    static int[] findSpot(MinecraftClient mc) {
        var w = mc.world; BlockPos f = mc.player.getBlockPos();
        int[] n = need();
        for (int y = f.getY(); y >= w.getBottomY() + 6; y--)
            for (int i = 0; i < 4; i++)
                if (volumeSolid(w, f, HD[i], y, n)) return new int[]{i, y};
        return null;
    }

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!on) return;
        if (p == null || w == null || mc.interactionManager == null) { on = false; return; }
        if (mc.currentScreen != null || !c.enabled || BlockSupply.busy()) return;

        if (phase == 0) {                                                    // bước khởi động
            BlockPos start = p.getBlockPos();
            stands.clear(); mined.clear(); cur = new ArrayList<>(); was.clear(); stands.add(start);
            if (c.tnSpot || c.tnSchem) {
                int[] sp = findSpot(mc);
                if (sp == null) { Util.msg("Không thấy chỗ đặc không hang trong vùng đã tải"); reset(mc); return; }
                dir = HD[sp[0]]; targetY = sp[1];
                Util.msg("Chỗ không hang: Y=" + targetY + " hướng " + dir.asString());
                if (start.getY() > targetY) phase = 1;
                else if (c.tnSchem) { Util.msg("Chỗ này đủ rộng cho schematic (x=" + start.getX() + " y=" + start.getY() + " z=" + start.getZ() + ")"); reset(mc); return; }
                else phase = 2;
            } else { dir = pickDir(p); phase = 2; }
        }
        if (phase == 3) { refillTick(mc); return; }
        if (ext && dug >= extSteps) { extDone = true; on = false; release(mc); return; }

        boolean stair = phase == 1 || c.tnDir == 5;
        if (dir == null) dir = pickDir(p);
        if (phase == 2 && c.tnLen > 0 && dug >= c.tnLen) { stop(mc, "đã đào đủ " + dug + " block"); return; }

        BlockPos feet = p.getBlockPos();
        List<BlockPos> cells = cellsFor(feet, dir, stair);

        // né lava: rẽ sang hướng khác
        if (c.tnSafe && lavaIn(w, cells)) {
            if (ext) { stop(mc, "gặp lava"); return; }
            Direction nd = null;
            for (Direction d : new Direction[]{dir.rotateYClockwise(), dir.rotateYCounterclockwise(), dir.getOpposite()}) {
                List<BlockPos> c2 = cellsFor(feet, d, stair);
                if (!lavaIn(w, c2)) { nd = d; break; }
            }
            if (nd == null) { stop(mc, "lava mọi phía"); return; }
            if (origDir == null) origDir = dir;
            dir = nd; detour = 0; release(mc);
            Util.msg("Gặp lava - đào sang hướng " + nd.asString());
            return;
        }

        // 0) đặt lại các ô phía sau lưng (đào 1 đặt 1 / đào 2 đặt 2)
        if (!pending.isEmpty()) { release(mc); fillNext(mc); return; }

        // 1) đào hết các ô phía trước
        for (BlockPos cell : cells) {
            if (AutoMine.passable(w, cell)) continue;
            if (!AutoMine.breakable(w, cell)) { stop(mc, "gặp block không đào được (" + cell.toShortString() + ")"); return; }
            release(mc);
            if (!was.containsKey(cell.asLong())) { was.put(cell.asLong(), w.getBlockState(cell).getBlock()); cur.add(cell); }
            AutoMine.mine(mc, cell);
            stuck = 0;
            return;
        }

        // 2) sàn phía trước hở -> cúi xuống đặt 1 block thường
        BlockPos ahead = feet.offset(dir);
        BlockPos stand = ahead.up(stair ? -1 : 0);
        BlockPos floor = stand.down();
        if (c.tnFloor && !ext && !solidFloor(w, floor)) {
            if (c.tnSafe && AutoMine.lava(w, floor)) { stop(mc, "sàn phía trước là lava"); return; }
            release(mc);
            if (!Util.has(TunnelDig::junk)) { stop(mc, "hết block để vá sàn"); return; }
            Util.aim(p, Vec3d.ofCenter(floor));
            for (int i = 0; i < 36; i++) {
                ItemStack s = p.getInventory().getStack(i);
                if (junk(s) && Util.placeBlock(floor, s.getItem())) return;
            }
            return;
        }

        // 3) bước tới
        Vec3d to = Vec3d.ofBottomCenter(stand);
        Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
        mc.options.forwardKey.setPressed(true); held = true;
        mc.options.jumpKey.setPressed(!stair && p.horizontalCollision && p.isOnGround());
        if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) < 0.3 && Math.abs(p.getY() - stand.getY()) < 0.9) {
            mined.add(cur); cur = new ArrayList<>(); stands.add(stand);       // ghi bước này
            stuck = 0;
            int k = mined.size();
            if (rolling() && k >= 2) { var back = new ArrayList<>(mined.get(k - 2)); back.sort(Comparator.comparingInt(BlockPos::getY)); pending.addAll(back); fails = 0; }
            if (phase == 1) {
                if (stand.getY() <= targetY) {
                    if (c.tnSchem) { Util.msg("Tới chỗ xây schematic (x=" + stand.getX() + " y=" + stand.getY() + " z=" + stand.getZ() + ")"); reset(mc); return; }
                    phase = 2; dug = 0;
                }
            } else {
                dug++;
                if (origDir != null) {                                         // đang đi vòng lava: hướng cũ hết lava thì quay lại
                    detour++;
                    if (!lavaIn(w, cellsFor(stand, origDir, stair))) { dir = origDir; origDir = null; Util.msg("Hết lava - quay lại hướng cũ"); }
                    else if (detour > 30) { stop(mc, "đi vòng lava quá xa"); return; }
                }
            }
        }
        if (p.getBlockPos().equals(lastPos)) { if (++stuck > 100) { stop(mc, "bị kẹt"); } } else { stuck = 0; lastPos = p.getBlockPos(); }
    }

    static void fillNext(MinecraftClient mc) {
        var p = mc.player; var w = mc.world;
        BlockPos cell = pending.peek();
        Block b = was.get(cell.asLong());
        if (b == null || !w.getBlockState(cell).isReplaceable()) { pending.poll(); return; }
        Item it = b.asItem();
        if (it == Items.AIR || !Util.has(s -> s.isOf(it))) {
            pending.poll();
            if (!warnedMissing) { warnedMissing = true; Util.warn("Thiếu đúng loại block để đặt lại (" + b.getName().getString() + ") - bỏ qua ô đó"); }
            return;
        }
        Util.aim(p, Vec3d.ofCenter(cell));                                     // nhìn vào ô rồi đặt
        if (Util.placeBlockLook(cell, it)) { pending.poll(); fails = 0; }
        else if (++fails > 8) { pending.poll(); fails = 0; }
    }

    // ---------- (cũ) lấp lại bằng cách đi lùi - không còn dùng ----------
    static void refillTick(MinecraftClient mc) {
        var p = mc.player; var w = mc.world;
        if (refillIdx < 0) {
            Util.msg(missing > 0 ? "Lấp xong (còn " + missing + " ô chưa lấp vì thiếu đúng loại block)" : "Lấp hầm xong");
            reset(mc); return;
        }
        BlockPos st = stands.get(Math.min(refillIdx, stands.size() - 1));
        Vec3d to = Vec3d.ofBottomCenter(st);
        if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) > 0.35 || Math.abs(p.getY() - st.getY()) > 0.9) {   // đi lùi về chỗ đứng của bước đó
            Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
            mc.options.forwardKey.setPressed(true); held = true;
            mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
            if (p.getBlockPos().equals(lastPos)) { if (++stuck > 120) { Util.msg("Bị kẹt khi quay lại - dừng lấp"); reset(mc); } } else { stuck = 0; lastPos = p.getBlockPos(); }
            return;
        }
        release(mc);
        List<BlockPos> cells = mined.get(refillIdx);
        while (cellIdx < cells.size()) {
            BlockPos cell = cells.get(cellIdx);
            Block b = was.get(cell.asLong());
            if (b == null || !w.getBlockState(cell).isReplaceable()) { cellIdx++; continue; }
            Item it = b.asItem();
            if (it == Items.AIR || !Util.has(s -> s.isOf(it))) { missing++; cellIdx++; continue; }
            Util.aim(p, Vec3d.ofCenter(cell));                                 // nhìn vào ô rồi đặt
            if (Util.placeBlockLook(cell, it)) { cellIdx++; fails = 0; }
            else if (++fails > 8) { missing++; cellIdx++; fails = 0; }
            return;
        }
        refillIdx--; cellIdx = 0; fails = 0;
    }
}
