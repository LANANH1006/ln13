package com.safeanchor;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.Heightmap;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.WorldChunk;

import java.util.*;

/**
 * Tìm chỗ xây base KHÔNG có hang: quét thể tích hang (khối air dưới mặt đất) của các chunk đã tải quanh tọa độ nhập,
 * rồi tìm khu (kích thước nhập hoặc theo schematic) mà mọi chunk trong khu + vành đai "xa hang N chunk" đều ít hang.
 * Hang nằm ngay trong tầng xây hoặc ngay trên đầu tính nặng hơn hang ở dưới. Kết quả hiện 4 trụ sáng ở 4 góc khu xây.
 * Chỉ quét được chunk server đã gửi (trong tầm render) - muốn dò chỗ xa thì tới gần tọa độ đó.
 */
public class BaseFinder {
    static final Map<Long, Integer> score = new HashMap<>();   // chunk -> điểm hang (càng cao càng nhiều hang)
    static final ArrayDeque<Long> queue = new ArrayDeque<>();
    static int total;
    public static boolean searching;
    public static String status = "";
    public static BlockPos resMin, resMax;                      // góc khu xây (y = Y xây ... Y xây + 12)
    static final List<Long> caveChunks = new ArrayList<>();

    // ---------- bắt đầu ----------
    public static void start(MinecraftClient mc) {
        if (mc.player == null || mc.world == null) { status = "Chưa vào thế giới"; return; }
        score.clear(); queue.clear(); caveChunks.clear(); resMin = resMax = null;
        int rd = mc.options.getViewDistance().getValue();
        int pcx = mc.player.getBlockX() >> 4, pcz = mc.player.getBlockZ() >> 4;
        List<Long> all = new ArrayList<>();
        for (int dx = -rd; dx <= rd; dx++) for (int dz = -rd; dz <= rd; dz++) {
            if (mc.world.getChunkManager().getWorldChunk(pcx + dx, pcz + dz) != null) all.add(ChunkPos.toLong(pcx + dx, pcz + dz));
        }
        final int tx = Config.I.bfX >> 4, tz = Config.I.bfZ >> 4;
        all.sort(Comparator.comparingDouble(k -> { ChunkPos c = new ChunkPos(k); return Math.hypot(c.x - tx, c.z - tz); }));
        queue.addAll(all);
        total = all.size();
        searching = true;
        double d = Math.hypot((Config.I.bfX) - mc.player.getX(), (Config.I.bfZ) - mc.player.getZ());
        status = "Đang quét " + total + " chunk đã tải..." + (d > rd * 16 ? " (tọa độ nhập nằm ngoài vùng tải, hãy tới gần hơn)" : "");
    }

    public static void clear() { score.clear(); queue.clear(); caveChunks.clear(); resMin = resMax = null; searching = false; status = "Đã xóa"; Config.I.bfOn = false; }

    // ---------- chấm điểm hang của 1 chunk ----------
    static int scoreChunk(WorldChunk wc, int baseY) {
        int[][] surf = new int[16][16];
        int maxLimit = -9999;
        for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) {
            surf[x][z] = wc.sampleHeightmap(Heightmap.Type.MOTION_BLOCKING_NO_LEAVES, x, z) - 6;   // bỏ lớp mặt đất / địa hình lồi lõm
            maxLimit = Math.max(maxLimit, surf[x][z]);
        }
        int cave = 0;
        ChunkSection[] secs = wc.getSectionArray();
        for (int i = 0; i < secs.length; i++) {
            ChunkSection sec = secs[i];
            int by = (wc.getBottomSectionCoord() + i) << 4;
            if (by > maxLimit || by > Config.I.bfMaxY) continue;
            if (!sec.isEmpty() && !sec.hasAny(st -> st.isAir())) continue;
            for (int x = 0; x < 16; x++) for (int z = 0; z < 16; z++) for (int y = 0; y < 16; y++) {
                int wy = by + y;
                if (wy > surf[x][z] || wy > Config.I.bfMaxY) break;      // chỉ tính hang từ tầng đá sâu (deepslate) trở xuống
                if (!sec.isEmpty() && !sec.getBlockState(x, y, z).isAir()) continue;
                // hang trong tầng xây nặng x6, hang phía trên đầu x3, hang bên dưới x1
                cave += (wy >= baseY && wy <= baseY + 12) ? 6 : (wy > baseY + 12 ? 3 : 1);
            }
        }
        return cave;
    }

    // ---------- tick ----------
    public static void tick(MinecraftClient mc) {
        if (!searching || mc.world == null || mc.player == null) return;
        for (int n = 0; n < 2 && !queue.isEmpty(); n++) {
            long k = queue.poll();
            ChunkPos cp = new ChunkPos(k);
            WorldChunk wc = mc.world.getChunkManager().getWorldChunk(cp.x, cp.z);
            if (wc != null) score.put(k, scoreChunk(wc, Config.I.bfY));
        }
        if (!queue.isEmpty()) { status = "Đang quét " + score.size() + "/" + total + " chunk..."; return; }
        searching = false;
        finish(mc);
    }

    static int sc(int cx, int cz) { return score.getOrDefault(ChunkPos.toLong(cx, cz), -1); }

    static void finish(MinecraftClient mc) {
        Config c = Config.I;
        int sizeX = c.bfSX, sizeZ = c.bfSZ;
        if (c.bfSchem && !Printer.blocks.isEmpty()) {            // kích thước khu xây theo schematic đã nạp
            int x0 = Integer.MAX_VALUE, x1 = Integer.MIN_VALUE, z0 = Integer.MAX_VALUE, z1 = Integer.MIN_VALUE;
            for (long l : Printer.blocks.keySet()) { BlockPos p = BlockPos.fromLong(l); x0 = Math.min(x0, p.getX()); x1 = Math.max(x1, p.getX()); z0 = Math.min(z0, p.getZ()); z1 = Math.max(z1, p.getZ()); }
            sizeX = x1 - x0 + 1; sizeZ = z1 - z0 + 1;
        }
        sizeX = Math.max(8, Math.min(128, sizeX)); sizeZ = Math.max(8, Math.min(128, sizeZ));
        int sx = (sizeX + 15) / 16, sz = (sizeZ + 15) / 16;
        int tol = c.bfTol, tcx = c.bfX >> 4, tcz = c.bfZ >> 4;
        Set<Integer> xs = new TreeSet<>(), zs = new TreeSet<>();
        for (long k : score.keySet()) { ChunkPos p = new ChunkPos(k); xs.add(p.x); zs.add(p.z); }
        if (xs.isEmpty()) { status = "Không có chunk nào để quét"; return; }
        int minX = Collections.min(xs), maxX = Collections.max(xs), minZ = Collections.min(zs), maxZ = Collections.max(zs);

        int usedM = -1; int bestX = 0, bestZ = 0; boolean bestValid = false;
        for (int m = c.bfFar; m >= 0 && usedM < 0; m--) {           // thiếu chunk để xa đủ N thì thử xa ít hơn
            double bestKey = Double.MAX_VALUE;
            for (int ax = minX + m; ax + sx - 1 + m <= maxX; ax++) for (int az = minZ + m; az + sz - 1 + m <= maxZ; az++) {
                int mx = 0; long sum = 0; boolean full = true;
                for (int x = ax - m; x <= ax + sx - 1 + m && full; x++) for (int z = az - m; z <= az + sz - 1 + m; z++) {
                    int s = sc(x, z); if (s < 0) { full = false; break; }
                    mx = Math.max(mx, s); sum += s;
                }
                if (!full) continue;
                boolean valid = mx <= tol;
                double dist = Math.hypot(ax + sx / 2.0 - tcx, az + sz / 2.0 - tcz);
                double key = (valid ? 0 : 1e9) + (valid ? dist : sum + dist * 0.01);
                if (key < bestKey) { bestKey = key; bestX = ax; bestZ = az; usedM = m; bestValid = valid; }
            }
        }
        if (usedM < 0) { status = "Chưa tải đủ chunk để kiểm tra - hãy tăng tầm nhìn (render distance) hoặc đứng gần hơn"; return; }

        int x0 = (bestX << 4) + (sx * 16 - sizeX) / 2, z0 = (bestZ << 4) + (sz * 16 - sizeZ) / 2;
        resMin = new BlockPos(x0, c.bfY, z0);
        resMax = new BlockPos(x0 + sizeX - 1, c.bfY + 12, z0 + sizeZ - 1);
        // hang gần nhất cách bao nhiêu chunk
        int near = 99;
        caveChunks.clear();
        for (var e : score.entrySet()) {
            if (e.getValue() <= tol) continue;
            ChunkPos p = new ChunkPos(e.getKey());
            int dx = p.x < bestX ? bestX - p.x : Math.max(0, p.x - (bestX + sx - 1)), dz = p.z < bestZ ? bestZ - p.z : Math.max(0, p.z - (bestZ + sz - 1));
            int d = Math.max(dx, dz);
            near = Math.min(near, d);
            if (d <= c.bfFar + 3) caveChunks.add(e.getKey());
        }
        status = (bestValid ? "§aTìm thấy" : "§eKhông có chỗ sạch hoàn toàn, đây là chỗ ít hang nhất")
                + ": X " + x0 + " → " + (x0 + sizeX - 1) + ", Z " + z0 + " → " + (z0 + sizeZ - 1) + ", Y " + c.bfY
                + (near == 99 ? " §7(không thấy hang nào trong vùng đã quét)" : " §7(hang gần nhất cách ~" + near + " chunk" + (usedM < c.bfFar ? ", đã giảm vành đai xuống " + usedM : "") + ")");
        c.bfOn = true;
        Util.msg("Tìm chỗ xây base xong");
    }

    // ---------- vẽ: 4 trụ sáng ở 4 góc + khung khu xây + các chunk có hang ----------
    public static void render(WorldRenderContext ctx) {
        Config c = Config.I;
        if (!c.enabled || !c.bfOn || resMin == null) return;
        List<BaseScan.Draw> list = new ArrayList<>();
        int x0 = resMin.getX(), z0 = resMin.getZ(), x1 = resMax.getX(), z1 = resMax.getZ();
        for (int x : new int[]{x0, x1}) for (int z : new int[]{z0, z1}) list.add(new BaseScan.Draw(new Box(x, -64, z, x + 1, 320, z + 1), 0x40FFD0, 70));   // trụ sáng
        list.add(new BaseScan.Draw(new Box(x0, resMin.getY(), z0, x1 + 1, resMax.getY(), z1 + 1), 0xFFE040, 22));                                       // khối khu xây
        if (c.bfCaves) for (long k : caveChunks) {
            ChunkPos p = new ChunkPos(k);
            list.add(new BaseScan.Draw(new Box(p.x * 16, c.bfY, p.z * 16, p.x * 16 + 16, c.bfY + 0.1, p.z * 16 + 16), 0xFF3030, 60));              // chunk có hang
            if (list.size() > 600) break;
        }
        BaseScan.paint(ctx, list);
    }
}
