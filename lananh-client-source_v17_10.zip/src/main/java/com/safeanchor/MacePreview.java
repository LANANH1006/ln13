package com.safeanchor;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.Items;

import java.util.ArrayList;
import java.util.List;

/** Màn hình nhỏ nhìn ngang: MÌNH (có cánh) và BOT. Chỉnh thông số nào là đường bay đổi theo thông số đó. kind 1 = Elytra Mace, 2 = Wind Mace. */
public class MacePreview {
    record Pt(double x, double y, boolean rk) {}

    static class Path { final List<Pt> pts = new ArrayList<>(); int swap = -1, hit = -1; double tx; }

    static void seg(Path p, double x0, double y0, double x1, double y1, boolean rk) {
        double len = Math.hypot(x1 - x0, y1 - y0);
        int n = Math.max(1, (int) (len / 0.6));
        if (p.pts.isEmpty()) p.pts.add(new Pt(x0, y0, rk));
        for (int i = 1; i <= n; i++) p.pts.add(new Pt(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n, rk));
    }

    static Path buildElytra(Config c) {
        Path p = new Path();
        double T = 40;
        double hd = Math.max(4, Math.min(40, c.maceHorizDive));
        double H = Math.min(46, c.maceDiveDist + 8);
        double bx = Math.max(6, T - hd - 6);
        p.tx = T;
        seg(p, 2, 0, bx, H, true);                                         // bay lên (pháo)
        if (false) {                                            // LAO PHÁO
            seg(p, bx, H, T, 1.8, true);
            p.hit = p.pts.size() - 1;
            double sw = Math.max(2, c.maceSwapDist);
            for (int i = p.hit; i >= 0; i--) if (Math.hypot(p.pts.get(i).x() - T, p.pts.get(i).y() - 1.8) >= sw) { p.swap = i; break; }
        } else {                                                           // THẢ RƠI
            double dx = Math.max(2, Math.min(8, hd * 0.2));
            seg(p, bx, H, T - dx, H, false);
            p.swap = p.pts.size() - 1;
            int n = 40;
            for (int i = 1; i <= n; i++) { double s = i / (double) n; p.pts.add(new Pt(T - dx + dx * s, H - (H - 1.8) * s * s, false)); }
            p.hit = p.pts.size() - 1;
        }
        seg(p, T, 1.8, Math.min(58, T + 10), H, true);                     // đánh xong: bay lên lại
        return p;
    }

    static Path buildWind(Config c) {
        Path p = new Path();
        double T = 34, sd = Math.max(2, Math.min(10, c.windStartDist));
        double x0 = T - sd - 3, top = 15;
        p.tx = T;
        for (int i = 0; i <= 24; i++) { double s = i / 24.0; p.pts.add(new Pt(x0 + (T - 2 - x0) * s, top * Math.sin(Math.PI / 2 * s), i < 6)); }   // wind charge hất lên
        p.swap = 0;
        int n = 22;
        for (int i = 1; i <= n; i++) { double s = i / (double) n; p.pts.add(new Pt(T - 2 + 2 * s, top - (top - 1.8) * s * s, false)); }         // rơi đập
        p.hit = p.pts.size() - 1;
        for (int i = 1; i <= 14; i++) { double s = i / 14.0; p.pts.add(new Pt(T + 5 * s, 1.8 + 8 * Math.sin(Math.PI * s), false)); }          // bật nhẹ
        return p;
    }

    static void person(DrawContext ctx, int x, int y, int body, boolean wings) {
        if (wings) { ctx.fill(x - 7, y - 3, x - 2, y, 0xFFB0B0C8); ctx.fill(x + 3, y - 3, x + 8, y, 0xFFB0B0C8); }
        ctx.fill(x - 2, y - 10, x + 2, y - 6, 0xFFF0C8A0);      // đầu
        ctx.fill(x - 2, y - 6, x + 2, y + 1, body);             // thân
        ctx.fill(x - 2, y + 1, x - 0, y + 5, 0xFF2A2A44);       // chân
        ctx.fill(x + 0, y + 1, x + 2, y + 5, 0xFF2A2A44);
    }

    public static void draw(DrawContext ctx, TextRenderer tr, int X, int Y, int W, int H, int kind) {
        Config c = Config.I;
        ctx.fillGradient(X, Y, X + W, Y + H, 0xFF1A1A33, 0xFF2D2548);          // "màn hình nhỏ": trời
        ctx.fill(X, Y, X + W, Y + 1, 0xFF8B5CF6); ctx.fill(X, Y + H - 1, X + W, Y + H, 0xFF8B5CF6);
        ctx.fill(X, Y, X + 1, Y + H, 0xFF8B5CF6); ctx.fill(X + W - 1, Y, X + W, Y + H, 0xFF8B5CF6);
        int gx0 = X + 8, gx1 = X + W - 8, gy = Y + H - 9, top = Y + 12;
        double sx = (gx1 - gx0) / 60.0, sy = (gy - top) / 50.0;
        ctx.fill(X + 1, gy + 5, X + W - 1, Y + H - 1, 0xFF2F5A34);             // đất
        ctx.fill(X + 1, gy + 5, X + W - 1, gy + 6, 0xFF4C8A52);

        Path p = kind == 2 ? buildWind(c) : buildElytra(c);
        int n = p.pts.size();
        double ph = (System.currentTimeMillis() % 6000L) / 6000.0;
        int cur = Math.min(n - 1, (int) (ph * n));
        for (int i = 0; i < n; i += 2) {                                        // vệt bay
            Pt q = p.pts.get(i);
            int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ctx.fill(px, py, px + 1, py + 1, i <= cur ? 0xFFC8A8FF : 0x66FFFFFF);
        }
        // BOT
        int tx = gx0 + (int) (p.tx * sx);
        boolean flash = cur >= p.hit && cur < p.hit + 6;
        person(ctx, tx, gy, flash ? 0xFFFF4040 : 0xFF3FA0FF, false);
        ctx.drawText(tr, "BOT", tx - 8, gy - 20, 0xFFFFFFFF, false);
        // mốc
        if (p.swap >= 0 && kind == 1) { Pt q = p.pts.get(p.swap); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ModIcons.draw(ctx, Items.IRON_CHESTPLATE, px - 4, py - 14, 0.5f); }
        if (p.hit >= 0) { Pt q = p.pts.get(p.hit); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
            ModIcons.draw(ctx, Items.MACE, px - 12, py - 10, 0.6f); }
        // MÌNH
        Pt q = p.pts.get(cur); int px = gx0 + (int) (q.x() * sx), py = gy - (int) (q.y() * sy);
        boolean glide = kind == 1 && !(cur > p.swap && cur <= p.hit);
        if (q.rk()) { ctx.fill(px - 1, py + 6, px + 1, py + 10, 0xFFFFA030); ModIcons.draw(ctx, kind == 2 ? Items.WIND_CHARGE : Items.FIREWORK_ROCKET, px + 6, py - 4, 0.5f); }
        person(ctx, px, py, 0xFF8B5CF6, glide);
        ctx.drawText(tr, "Mình", px - 9, py - 20, 0xFFFFE08A, false);
        // chữ ngắn
        String t1 = kind == 2 ? "§bWind §7ném §f" + (int) c.windStartDist + "§7  cd §f" + c.windMinCd + "%"
                : "§bThả rơi" + "§7  cao §f" + (int) (c.maceDiveDist + 8) + "§7  lệch §f" + (int) c.maceHorizDive + "§7  áo §f" + (int) c.maceSwapDist;
        ctx.drawText(tr, t1, X + 5, Y + 3, 0xFFFFFFFF, false);
    }
}
