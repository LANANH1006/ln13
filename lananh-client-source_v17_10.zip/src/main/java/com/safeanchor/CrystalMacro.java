package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Macro Crystal: cầm crystal + giữ chuột phải, nhìn vào obsidian/bedrock -> mỗi tick:
 *  1) đập nổ tối đa N crystal trong tầm (N = macroPerTick, tới 30) - bỏ qua crystal làm bạn chết;
 *  2) đặt lại crystal lên block đang ngắm ngay trong cùng tick (server xử lý đúng thứ tự: nổ -> đặt).
 * Lưu ý: crystal vừa đặt phải được server báo về mới đập được, nên 1 block đặt - nổ tối đa 1 lần / tick;
 * con số N lớn chỉ có tác dụng khi có nhiều crystal cùng nằm trong tầm.
 */
public class CrystalMacro {
    static int cd, ttl;
    static BlockPos base;
    static final Map<Integer, Long> recent = new HashMap<>();

    static boolean isBase(net.minecraft.block.BlockState s) { return s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK); }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.crystalMacro || !c.enabled || p == null || w == null || mc.interactionManager == null || mc.currentScreen != null) { ttl = 0; return; }
        if (cd > 0) cd--;
        if (!p.getMainHandStack().isOf(Items.END_CRYSTAL) || !mc.options.useKey.isPressed()) { ttl = 0; return; }

        // nhớ obsidian/bedrock đang ngắm (sau khi đặt, tâm sẽ chuyển sang crystal nên cần nhớ lại)
        if (mc.crosshairTarget instanceof BlockHitResult bh && bh.getType() == HitResult.Type.BLOCK) {
            if (isBase(w.getBlockState(bh.getBlockPos()))) { base = bh.getBlockPos(); ttl = 12; }
        } else if (ttl > 0) ttl--;
        if (ttl <= 0 || base == null || cd > 0) return;

        double reach = Math.max(3.0, c.reach);
        long now = w.getTime();
        if (recent.size() > 200) recent.clear();

        // ---- 1) đập nổ nhiều crystal ----
        List<EndCrystalEntity> list = new ArrayList<>();
        Box area = c.macroAll ? p.getBoundingBox().expand(reach + 1) : new Box(base.up()).expand(0.6);
        for (EndCrystalEntity e : w.getEntitiesByClass(EndCrystalEntity.class, area, x -> true)) {
            if (e.isRemoved()) continue;
            Long t = recent.get(e.getId());
            if (t != null && now - t < 2) continue;
            if (Util.distToBox(p.getEyePos(), e.getBoundingBox()) > reach) continue;
            if (Util.selfDamage(p, e.getPos()) >= p.getHealth() + p.getAbsorptionAmount()) continue;   // không tự sát
            list.add(e);
        }
        list.sort((a, b) -> Double.compare(a.squaredDistanceTo(p), b.squaredDistanceTo(p)));
        int max = Util.cap(Math.max(1, Math.min(30, c.macroPerTick))), hits = 0;
        for (EndCrystalEntity e : list) {
            if (hits >= max) break;
            mc.interactionManager.attackEntity(p, e);
            recent.put(e.getId(), now);
            hits++;
        }
        if (hits > 0) p.swingHand(Hand.MAIN_HAND);

        // ---- 2) đặt lại crystal ngay (cùng tick) ----
        if (c.macroPlace && isBase(w.getBlockState(base))
                && w.getBlockState(base.up()).isAir() && w.getBlockState(base.up(2)).isAir()) {
            boolean blocked = false;                                           // chỉ crystal (vừa đập) mới được nằm ở ô đó
            for (var o : w.getOtherEntities(null, new Box(base.up()))) if (!(o instanceof EndCrystalEntity)) { blocked = true; break; }
            Vec3d hit = Vec3d.ofCenter(base).add(0, 0.5, 0);
            if (!blocked && p.getEyePos().distanceTo(hit) <= reach) {
                Util.interact(p, Hand.MAIN_HAND, new BlockHitResult(hit, Direction.UP, base, false));
                p.swingHand(Hand.MAIN_HAND);
            }
        }
        if (hits > 0 || c.macroPlace) cd = Util.pace(Math.max(0, c.macroDelay));
    }
}
