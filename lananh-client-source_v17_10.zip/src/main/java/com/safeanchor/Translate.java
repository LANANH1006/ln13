package com.safeanchor;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientSendMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Pattern;

/**
 * Dịch chat như Google Dịch.
 * Gửi: bạn gõ gì (tiếng Việt, không dấu, ngôn ngữ nào cũng được) -> tự đổi sang ngôn ngữ "Gửi sang" (mặc định tiếng Anh) rồi mới gửi.
 * Nhận: tin của người khác được ĐỔI THẲNG sang ngôn ngữ "Nhận sang" (mặc định tiếng Việt): dòng gốc bị ẩn, dòng đã dịch hiện thay vào đó.
 */
public class Translate {
    static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(4)).build();
    static final Pattern LETTERS = Pattern.compile("\\p{L}{2,}");
    static final Pattern VI = Pattern.compile("[àáạảãăằắặẳẵâầấậẩẫđèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹ]", Pattern.CASE_INSENSITIVE);
    public static final String[] LANGS = {"en", "vi", "es", "fr", "de", "ru", "pt", "id", "tr", "ja", "ko", "zh-CN"};
    static boolean bypass;

    record Res(String text, String src) {}

    static final Map<String, Res> CACHE = new LinkedHashMap<>(256, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Res> e) { return size() > 300; }
    };

    public static int langIndex(String code) { for (int i = 0; i < LANGS.length; i++) if (LANGS[i].equalsIgnoreCase(code)) return i; return 0; }

    static CompletableFuture<Res> translate(String text, String to) {
        String key = to + "|" + text;
        synchronized (CACHE) { Res c = CACHE.get(key); if (c != null) return CompletableFuture.completedFuture(c); }
        String url = "https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + to + "&dt=t&q=" + URLEncoder.encode(text, StandardCharsets.UTF_8);
        HttpRequest rq = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(5)).header("User-Agent", "Mozilla/5.0").build();
        return HTTP.sendAsync(rq, HttpResponse.BodyHandlers.ofString()).thenApply(r -> {
            JsonArray root = JsonParser.parseString(r.body()).getAsJsonArray();
            StringBuilder sb = new StringBuilder();
            for (JsonElement e : root.get(0).getAsJsonArray()) sb.append(e.getAsJsonArray().get(0).getAsString());
            String src = root.size() > 2 && !root.get(2).isJsonNull() ? root.get(2).getAsString() : "";
            Res res = new Res(sb.toString(), src);
            synchronized (CACHE) { CACHE.put(key, res); }
            return res;
        });
    }

    static boolean sameLang(String a, String b) { return a != null && b != null && a.toLowerCase().startsWith(b.toLowerCase().split("-")[0]); }

    // ---------------- NHẬN ----------------
    /** Vị trí kết thúc phần tên người gửi ("<Tên> ", "Tên » ", "Tên: ") để chỉ dịch phần nội dung. 0 = không rõ. */
    static int split(String s) {
        int i;
        if (s.startsWith("<")) { i = s.indexOf("> "); if (i > 0 && i < 40) return i + 2; }
        i = s.indexOf(" » "); if (i > 0 && i < 60) return i + 3;
        i = s.indexOf("» "); if (i > 0 && i < 60) return i + 2;
        i = s.indexOf(" > "); if (i > 0 && i < 60) return i + 3;
        i = s.indexOf(": "); if (i > 0 && i < 40) return i + 2;
        return 0;
    }

    /** Dựng lại dòng chat: giữ nguyên màu / kiểu của phần tên, thay phần nội dung bằng bản dịch. */
    static Text rebuild(Text orig, int prefixLen, String body) {
        MutableText out = Text.empty();
        int[] pos = {0};
        Style[] bodyStyle = {Style.EMPTY};
        boolean[] got = {false};
        orig.visit((style, str) -> {
            if (pos[0] < prefixLen) {
                int take = Math.min(str.length(), prefixLen - pos[0]);
                out.append(Text.literal(str.substring(0, take)).setStyle(style));
                if (take < str.length() && !got[0]) { bodyStyle[0] = style; got[0] = true; }
            } else if (!got[0]) { bodyStyle[0] = style; got[0] = true; }
            pos[0] += str.length();
            return Optional.empty();
        }, Style.EMPTY);
        out.append(Text.literal(body).setStyle(bodyStyle[0]));
        return out;
    }

    static void show(Text t) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> { if (mc.inGameHud != null) mc.inGameHud.getChatHud().addMessage(t); });
    }

    /** true = cho hiện dòng gốc như thường; false = ẩn dòng gốc (dòng đã dịch sẽ hiện thay thế). */
    static boolean incoming(Text msg, boolean own) {
        Config c = Config.I;
        if (!c.enabled || !c.trOn || !c.chatIn || own) return true;
        String s = msg.getString();
        int pre = split(s);
        String body = s.substring(pre).strip();
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null && pre > 0 && s.substring(0, pre).contains(mc.player.getName().getString())) return true;   // tin của chính mình
        if (body.length() < 3 || !LETTERS.matcher(body).find()) return true;
        String to = c.trIn;
        if (to.equals("vi") && VI.matcher(body).find()) return true;           // đã là tiếng Việt
        final int p = pre; final String bd = body;
        translate(bd, to).thenAccept(r -> {
            if (r == null || r.text().isBlank() || sameLang(r.src(), to) || r.text().equalsIgnoreCase(bd)) show(msg);
            else show(rebuild(msg, p, r.text()));
        }).exceptionally(ex -> { show(msg); return null; });
        return false;
    }

    // ---------------- GỬI ----------------
    static void send(String s) {
        MinecraftClient mc = MinecraftClient.getInstance();
        mc.execute(() -> {
            if (mc.player == null || mc.getNetworkHandler() == null) return;
            bypass = true;
            try { mc.getNetworkHandler().sendChatMessage(s); } finally { bypass = false; }
        });
    }

    public static void init() {
        ClientReceiveMessageEvents.ALLOW_GAME.register((msg, overlay) -> overlay || incoming(msg, false));
        ClientReceiveMessageEvents.ALLOW_CHAT.register((msg, signed, sender, params, ts) -> {
            MinecraftClient mc = MinecraftClient.getInstance();
            boolean own = sender != null && mc.player != null && sender.getId().equals(mc.player.getUuid());
            Config c = Config.I;
            if (!c.enabled || !c.trOn || !c.chatIn || own) return true;
            String body = msg.getString().strip();
            if (body.length() < 3 || !LETTERS.matcher(body).find()) return true;
            String to = c.trIn;
            if (to.equals("vi") && VI.matcher(body).find()) return true;
            Text decorated = params.applyChatDecoration(msg);
            translate(body, to).thenAccept(r -> {
                if (r == null || r.text().isBlank() || sameLang(r.src(), to) || r.text().equalsIgnoreCase(body)) show(decorated);
                else show(params.applyChatDecoration(Text.literal(r.text())));
            }).exceptionally(ex -> { show(decorated); return null; });
            return false;
        });
        ClientSendMessageEvents.ALLOW_CHAT.register(msg -> {
            Config c = Config.I;
            if (bypass || !c.enabled || !c.trOn || !c.chatOut) return true;
            String t = msg.strip();
            if (t.length() < 2 || !LETTERS.matcher(t).find()) return true;
            translate(t, c.trOut).thenAccept(r -> send(r == null || r.text().isBlank() || sameLang(r.src(), c.trOut) ? t : r.text()))
                    .exceptionally(ex -> { send(t); return null; });
            return false;
        });
    }
}
