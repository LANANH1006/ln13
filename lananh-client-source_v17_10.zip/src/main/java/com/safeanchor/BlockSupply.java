package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;

import java.util.function.Predicate;

/**
 * Chống rớt khi đang auto đào:
 *  - Đang rơi (rớt > 2 block) mà có block -> lấy block ra hotbar, đặt dưới chân làm đài đỡ.
 *  - Không có block -> /shop: bấm Đá End, bấm Đá End lần nữa, bấm +64, bấm Mua. Có block rồi thì đặt tiếp.
 * (GUI /shop mỗi server khác nhau: mod tìm ô theo loại item / tên "+64" / "mua", cần thử trên KingMC.)
 */
public class BlockSupply {
    static int stage, wait, timeout, cooldown, tries;

    public static boolean busy() { return stage > 0; }

    static boolean digging() { return TunnelDig.on || AreaSweep.active || AutoMine.areaActive(); }

    static boolean isSupply(ItemStack s) {
        return s.getItem() instanceof BlockItem bi && (TunnelDig.JUNK.contains(bi.getBlock()) || bi.getBlock() == Blocks.END_STONE);
    }

    static Item findSupply(net.minecraft.entity.player.PlayerEntity p) {
        var inv = p.getInventory();
        for (int i = 0; i < 36; i++) if (isSupply(inv.getStack(i))) return inv.getStack(i).getItem();
        return null;
    }

    static int find(GenericContainerScreenHandler h, Predicate<ItemStack> pr) {
        int n = h.getRows() * 9;
        for (int i = 0; i < n; i++) { ItemStack s = h.getSlot(i).getStack(); if (!s.isEmpty() && pr.test(s)) return i; }
        return -1;
    }

    static void abort(MinecraftClient mc, String why) {
        Util.warn("Mua block thất bại: " + why);
        stage = 0; cooldown = 400; tries = 0;
        if (mc.player != null && mc.currentScreen instanceof GenericContainerScreen) mc.player.closeHandledScreen();
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (p == null || w == null || mc.interactionManager == null) { stage = 0; return; }
        if (stage > 0) { shopTick(mc); return; }
        if (cooldown > 0) { cooldown--; return; }
        if (!c.fallCatch || !c.enabled || !digging() || mc.currentScreen != null) return;

        boolean falling = !p.isOnGround() && p.fallDistance > 2.0 && !p.isTouchingWater() && !p.getAbilities().flying;
        if (!falling) return;

        Item it = findSupply(p);
        if (it != null) {                                                      // có block: lấy ra hotbar, đặt đài dưới chân
            BlockPos feet = p.getBlockPos();
            for (int d = 1; d <= 3; d++) if (Util.placeBlock(feet.down(d), it)) return;
            return;
        }
        if (c.shopRestock) {                                                   // không có block: mua bằng /shop
            Util.warn("Hết block - mua đá End bằng /shop");
            stage = 1; wait = 15; timeout = 0; tries = 0;
            p.networkHandler.sendChatCommand("shop");
        }
    }

    static void shopTick(MinecraftClient mc) {
        var p = mc.player;
        if (wait > 0) { wait--; return; }

        if (stage == 5) {                                                      // xong: đóng GUI, kiểm tra đã có block chưa
            if (mc.currentScreen instanceof GenericContainerScreen) p.closeHandledScreen();
            if (findSupply(p) != null) { stage = 0; cooldown = 20; tries = 0; Util.msg("Đã mua block"); }
            else if (++tries < 3) { stage = 1; wait = 15; timeout = 0; p.networkHandler.sendChatCommand("shop"); }
            else abort(mc, "mua xong vẫn không thấy block trong túi");
            return;
        }
        if (!(mc.currentScreen instanceof GenericContainerScreen gs)) {
            if (++timeout > 60) abort(mc, "không mở được /shop");
            return;
        }
        timeout = 0;
        GenericContainerScreenHandler h = gs.getScreenHandler();
        int slot;
        switch (stage) {
            case 1, 2 -> {                                                     // bấm Đá End (2 lần)
                slot = find(h, s -> s.isOf(Items.END_STONE));
                if (slot < 0) { if (stage == 2) { stage = 3; wait = 2; return; } abort(mc, "không thấy Đá End trong /shop"); return; }
                mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);
                stage++; wait = 8;
            }
            case 3 -> {                                                        // bấm +64
                slot = find(h, s -> s.getName().getString().contains("+64") || s.getName().getString().contains("64") && s.getName().getString().contains("+"));
                if (slot < 0) { if (++tries > 20) abort(mc, "không thấy nút +64"); wait = 3; return; }
                mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);
                stage = 4; wait = 6; tries = 0;
            }
            case 4 -> {                                                        // bấm Mua
                slot = find(h, s -> {
                    String n = s.getName().getString().toLowerCase();
                    return n.contains("mua") || n.contains("buy") || n.contains("confirm") || n.contains("xác nhận") || AutoAh.CONFIRM.contains(s.getItem());
                });
                if (slot < 0) { if (++tries > 20) abort(mc, "không thấy nút Mua"); wait = 3; return; }
                mc.interactionManager.clickSlot(h.syncId, slot, 0, SlotActionType.PICKUP, p);
                stage = 5; wait = 12; tries = 0;
            }
            default -> stage = 0;
        }
    }
}
