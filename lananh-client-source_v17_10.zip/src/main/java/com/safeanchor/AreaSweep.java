package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

/**
 * FreeDig với cúp amethyst (đào 3x3): đào theo ĐƯỜNG THẲNG đi - rẽ - quay lại (kiểu cắt cỏ), từng tầng 3 block từ trên xuống,
 * không đào lung tung. Mỗi hàng rộng 3 (khớp cúp), hàng chạy dọc trục X, rẽ sang hàng kế bên dọc trục Z.
 */
public class AreaSweep {
    public static boolean active;
    public static BlockPos a, b;
    static final List<Integer> centers = new ArrayList<>();
    static int f, zi, zDir, row, stage, tmo, goalF, nextZi;
    static BlockPos start;

    public static void start(MinecraftClient mc, BlockPos min, BlockPos max) {
        a = min; b = max; active = true;
        centers.clear();
        int w = b.getZ() - a.getZ() + 1;
        if (w <= 3) centers.add(a.getZ() + w / 2);
        else for (int z = a.getZ() + 1; z - 1 <= b.getZ(); z += 3) {
            int c = Math.min(z, b.getZ() - 1);
            if (!centers.contains(c)) centers.add(c);
            if (z + 1 >= b.getZ()) break;
        }
        f = Math.max(a.getY(), b.getY() - 2);          // tầng trên cùng: dải 3 block cao [f, f+2]
        zi = 0; zDir = 1; row = 0; stage = 0; tmo = 0;
        start = new BlockPos(a.getX(), f, centers.get(0));
        AutoMine.startArea(new BlockPos(a.getX(), f, start.getZ() - 1), new BlockPos(a.getX(), f + 2, start.getZ() + 1));   // đào + đi tới điểm bắt đầu
        Util.msg("Cúp amethyst: " + centers.size() + " hàng mỗi tầng, đào thẳng đi rồi quay lại");
    }

    public static void stop(MinecraftClient mc) {
        if (!active) return;
        active = false;
        TunnelDig.abort(mc);
        AutoMine.stopArea(mc);
        release(mc);
    }

    static void fail(MinecraftClient mc, String why) { Util.warn("FreeDig amethyst dừng: " + why); stop(mc); }

    static void release(MinecraftClient mc) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); }

    static Direction rowDir() { return row % 2 == 0 ? Direction.EAST : Direction.WEST; }

    public static void tick(MinecraftClient mc) {
        if (!active) return;
        var p = mc.player; var w = mc.world;
        if (p == null || w == null) { active = false; return; }
        if (mc.currentScreen != null || BlockSupply.busy()) return;
        switch (stage) {
            case 0 -> {                                                          // 0: AutoMine đào + tới gần điểm bắt đầu
                if (!AutoMine.areaActive()) { stage = 1; tmo = 0; }
            }
            case 1 -> {                                                          // 1: đi vào đúng ô bắt đầu
                Vec3d to = Vec3d.ofBottomCenter(start);
                if (Math.hypot(p.getX() - to.x, p.getZ() - to.z) < 0.4 && Math.abs(p.getY() - start.getY()) < 1.2) { release(mc); beginRow(mc); return; }
                Util.aim(p, new Vec3d(to.x, p.getEyeY(), to.z));
                mc.options.forwardKey.setPressed(true);
                mc.options.jumpKey.setPressed(p.horizontalCollision && p.isOnGround());
                if (++tmo > 300) fail(mc, "không tới được điểm bắt đầu, hãy đứng gần góc khu vực");
            }
            case 2 -> {                                                          // 2: đang đào 1 hàng thẳng
                if (TunnelDig.extDone) { afterRow(mc); }
                else if (!TunnelDig.on) fail(mc, "đào bị dừng (lava / block không đào được / kẹt)");
            }
            case 3 -> {                                                          // 3: rẽ sang hàng kế bên
                if (TunnelDig.extDone) { zi = nextZi; row++; beginRow(mc); }
                else if (!TunnelDig.on) fail(mc, "đào bị dừng khi rẽ hàng");
            }
            case 4 -> {                                                          // 4: đào xuống tầng kế
                BlockPos feet = p.getBlockPos();
                if (feet.getY() <= goalF) { release(mc); f = goalF; zDir = -zDir; row++; beginRow(mc); return; }
                BlockPos cell = feet.down();
                if (!AutoMine.passable(w, cell)) {
                    if (!AutoMine.breakable(w, cell)) { fail(mc, "gặp block không đào được ở dưới"); return; }
                    AutoMine.mine(mc, cell);
                }
                if (++tmo > 400) fail(mc, "không đào xuống được");
            }
            default -> stop(mc);
        }
    }

    static void beginRow(MinecraftClient mc) {
        stage = 2;
        int steps = b.getX() - a.getX();
        if (steps <= 0) { TunnelDig.extDone = true; afterRow(mc); return; }
        TunnelDig.beginSegment(mc, rowDir(), steps);
    }

    static void afterRow(MinecraftClient mc) {
        TunnelDig.extDone = false;
        int ni = zi + zDir;
        if (ni >= 0 && ni < centers.size()) {                                    // còn hàng kế bên -> rẽ
            nextZi = ni;
            int steps = Math.abs(centers.get(ni) - centers.get(zi));
            stage = 3;
            TunnelDig.beginSegment(mc, zDir > 0 ? Direction.SOUTH : Direction.NORTH, steps);
            return;
        }
        if (f <= a.getY()) { Util.msg("FreeDig amethyst: đào xong vùng"); stop(mc); return; }   // hết tầng cuối
        goalF = Math.max(a.getY(), f - 3);                                       // xuống tầng kế (3 block)
        stage = 4; tmo = 0;
    }
}
