package com.safeanchor;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

/** Tự đặt obsidian + crystal cạnh đối thủ (hoặc chỗ pearl rơi) và tự nổ khi đủ gần. */
public class AutoCrystal {
    static int cd, obsCd;
    public static PlayerEntity hitTarget; public static int hitTicks;

    public static void tick(MinecraftClient mc) {
        Config c = Config.I; var p = mc.player; var w = mc.world;
        if (!c.crystal || !c.enabled || p == null || w == null || mc.interactionManager == null) return;
        if (hitTicks > 0) hitTicks--;
        if (obsCd > 0) obsCd--;
        if (cd > 0) { cd--; return; }

        Vec3d focus = null;
        PlayerEntity t = (hitTicks > 0 && hitTarget != null && hitTarget.isAlive() && hitTarget.distanceTo(p) < 10) ? hitTarget : Util.nearestEnemy(8);
        if (t != null) focus = t.getPos();
        else if (c.pearlCrystal) focus = Util.pearlLanding();
        if (focus == null) return;
        // đối thủ bị văng lên: lấy điểm mặt đất bên dưới để đặt/nổ
        BlockPos gp = BlockPos.ofFloored(focus);
        for (int i = 0; i < 8 && w.getBlockState(gp.down()).isAir(); i++) gp = gp.down();
        focus = new Vec3d(focus.x, gp.getY(), focus.z);

        // 1) nổ crystal đang có
        EndCrystalEntity best = null; double bd = 1e9;
        for (EndCrystalEntity e : w.getEntitiesByClass(EndCrystalEntity.class, new Box(p.getPos(), p.getPos()).expand(7), x -> true)) {
            if (Util.distToBox(p.getEyePos(), e.getBoundingBox()) > c.crystalRange) continue;
            double d = e.getPos().distanceTo(focus);
            if (d > c.crystalExplodeDist) continue;
            double self = Util.selfDamage(p, e.getPos());
            if (self > c.maxSelfDamage || p.getHealth() + p.getAbsorptionAmount() - self < 2) continue;
            if (d < bd) { bd = d; best = e; }
        }
        if (best != null) {
            mc.interactionManager.attackEntity(p, best); p.swingHand(Hand.MAIN_HAND);
            cd = c.crystalDelay; return;
        }

        // 2) đặt crystal lên obsidian/bedrock có sẵn
        BlockPos fp = gp;
        BlockPos bestBase = null; double bestD = 1e9;
        for (int dx = -3; dx <= 3; dx++) for (int dz = -3; dz <= 3; dz++) for (int dy = -2; dy <= 1; dy++) {
            BlockPos base = fp.add(dx, dy - 1, dz);
            var bs = w.getBlockState(base);
            if (!bs.isOf(Blocks.OBSIDIAN) && !bs.isOf(Blocks.BEDROCK)) continue;
            if (!w.getBlockState(base.up()).isAir() || !w.getBlockState(base.up(2)).isAir()) continue;
            Vec3d cpos = Vec3d.ofCenter(base).add(0, 1.0, 0);
            if (p.getEyePos().distanceTo(Vec3d.ofCenter(base).add(0, 0.5, 0)) > c.crystalRange) continue;
            double d = cpos.distanceTo(focus);
            if (d > c.crystalExplodeDist || d < 1.0) continue;
            if (!w.getOtherEntities(null, new Box(base.up())).isEmpty()) continue;
            double self = Util.selfDamage(p, cpos);
            if (self > c.maxSelfDamage) continue;
            if (d < bestD) { bestD = d; bestBase = base; }
        }
        if (bestBase != null && Util.selectItem(s -> s.isOf(Items.END_CRYSTAL))) {
            Util.useOnBlock(bestBase, Direction.UP);
            cd = c.crystalDelay; return;
        }

        // 3) chưa có nền: tự đặt obsidian cạnh mục tiêu
        if (c.crystalAutoObs && obsCd == 0 && !AutoAnchor.busy() && AnchorCombo.stage == 0
                && Util.has(s -> s.isOf(Items.OBSIDIAN)) && Util.has(s -> s.isOf(Items.END_CRYSTAL))) {
            Vec3d away = new Vec3d(focus.x - p.getX(), 0, focus.z - p.getZ());
            if (away.lengthSquared() > 1e-4) {
                away = away.normalize();
                BlockPos back = BlockPos.ofFloored(focus.add(away.x * 1.0, 0, away.z * 1.0));
                if (w.getBlockState(back).isReplaceable() && !w.getBlockState(back.down()).isAir() && w.getBlockState(back.up()).isAir()
                        && p.getEyePos().distanceTo(Vec3d.ofCenter(back)) <= c.crystalRange
                        && w.getOtherEntities(null, new Box(back)).isEmpty() && Util.placeBlock(back, Items.OBSIDIAN)) { cd = 1; obsCd = 10; return; }
            }
            BlockPos pick = null; double pd = 1e9;
            for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
                if (dx == 0 && dz == 0) continue;
                BlockPos q = fp.add(dx, 0, dz);
                if (!w.getBlockState(q).isReplaceable() || w.getBlockState(q.down()).isAir()) continue;
                if (!w.getBlockState(q.up()).isAir()) continue;
                if (p.getEyePos().distanceTo(Vec3d.ofCenter(q)) > c.crystalRange) continue;
                if (!w.getOtherEntities(null, new Box(q)).isEmpty()) continue;
                double d = Vec3d.ofCenter(q).distanceTo(focus);
                if (d < pd) { pd = d; pick = q; }
            }
            if (pick != null && Util.placeBlock(pick, Items.OBSIDIAN)) { cd = 1; obsCd = 10; }
        }
    }
}
